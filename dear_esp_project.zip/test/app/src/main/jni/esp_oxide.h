// esp_oxide.h - read-only ESP for com.catsbit.oxidesurvuvalisland, build 1.17.11995 (arm64)
// reads only: Object.FindObjectsOfType(Type) for Oxide.PlayerManager, then Transform.position of each hit.
// writes nothing into game memory. no hooks, no network. drawing goes to the ImGui background list.
// RVAs: off_oxide_1.17.11995.h (from dump.cs of this build). game update = RVAs wrong, re-dump.
#pragma once
#include <dlfcn.h>
#include <cstdint>
#include <cmath>
#include <Includes/Utils.h>
#include "ImGui/imgui.h"
#include "ByNameModding/Il2Cpp.h"
#include "off_oxide_1.17.11995.h"

struct EspVec3 { float x, y, z; };

namespace esp {
    typedef void*   (*FindAll_t)(void* type, void* method);
    typedef void*   (*ClassGetType_t)(void* klass);
    typedef void*   (*TypeGetObject_t)(void* type);
    typedef void*   (*GetTransform_t)(void* self, void* method);
    typedef EspVec3 (*GetPosition_t)(void* transform, void* method);
    typedef bool    (*GetIsLocal_t)(void* self, void* method);
    typedef void*   (*GetMain_t)(void* method);
    typedef EspVec3 (*W2S_t)(void* camera, EspVec3 pos, void* method);

    static bool          ready = false;
    static void*         typeObj = nullptr;
    static FindAll_t     findAll = nullptr;
    static GetTransform_t getTransform = nullptr;
    static GetPosition_t  getPosition = nullptr;
    static GetIsLocal_t   isLocal = nullptr;
    static GetMain_t      getMain = nullptr;
    static W2S_t          w2s = nullptr;

    // call once from the hack thread, after libil2cpp.so is loaded
    static void Init() {
        Il2CppAttach("libil2cpp.so");
        void* h = dlopen("libil2cpp.so", RTLD_NOW);
        if (!h) return;
        auto classGetType  = (ClassGetType_t)  dlsym(h, "il2cpp_class_get_type");
        auto typeGetObject = (TypeGetObject_t) dlsym(h, "il2cpp_type_get_object");
        void* klass = Il2CppGetClassType("Assembly-CSharp.dll", "Oxide", "PlayerManager");
        if (!classGetType || !typeGetObject || !klass) return;
        typeObj      = typeGetObject(classGetType(klass));
        findAll      = (FindAll_t)      getAbsoluteAddress("libil2cpp.so", off::Object_FindObjectsOfType_Type);
        getTransform = (GetTransform_t) getAbsoluteAddress("libil2cpp.so", off::Component_get_transform);
        getPosition  = (GetPosition_t)  getAbsoluteAddress("libil2cpp.so", off::Transform_get_position);
        isLocal      = (GetIsLocal_t)   getAbsoluteAddress("libil2cpp.so", off::NetworkBehaviour_get_isLocalPlayer);
        getMain      = (GetMain_t)      getAbsoluteAddress("libil2cpp.so", off::Camera_get_main);
        w2s          = (W2S_t)          getAbsoluteAddress("libil2cpp.so", off::Camera_WorldToScreenPoint);
        ready = typeObj && findAll && getTransform && getPosition && isLocal && getMain && w2s;
    }

    // call every frame from step(), after the ImGui frame has started
    // FindObjectsOfType runs every frame: simple and always fresh, costs a scene scan. if it lags, throttle it.
    static void Draw(bool box, bool line, ImVec4 boxCol, ImVec4 lineCol, float thick) {
        if (!ready) return;
        void* cam = getMain(nullptr);
        if (!cam) return;
        void* arr = findAll(typeObj, nullptr);             // Object[] -> Il2CppArray*
        if (!arr) return;
        uint64_t n = *(uint64_t*)((char*)arr + 0x18);      // il2cpp_array max_length
        if (n > 512) n = 512;
        void** items = (void**)((char*)arr + 0x20);        // first element
        ImGuiIO& io = ImGui::GetIO();
        const float sw = io.DisplaySize.x, sh = io.DisplaySize.y;
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const ImU32 boxU  = ImGui::ColorConvertFloat4ToU32(boxCol);
        const ImU32 lineU = ImGui::ColorConvertFloat4ToU32(lineCol);
        for (uint64_t i = 0; i < n; ++i) {
            void* pm = items[i];
            if (!pm || isLocal(pm, nullptr)) continue;     // skip own player
            void* tr = getTransform(pm, nullptr);
            if (!tr) continue;
            EspVec3 p    = getPosition(tr, nullptr);
            EspVec3 head = { p.x, p.y + 1.6f, p.z };
            EspVec3 hs   = w2s(cam, head, nullptr);
            EspVec3 fs   = w2s(cam, p, nullptr);
            if (hs.z <= 0.f || fs.z <= 0.f) continue;      // behind camera
            float top = sh - hs.y;                          // unity y is bottom-up, imgui is top-down
            float bot = sh - fs.y;
            float h = std::fabs(bot - top);
            if (h < 2.f) continue;
            float w = h * 0.5f;
            if (box)  dl->AddRect(ImVec2(fs.x - w * 0.5f, top), ImVec2(fs.x + w * 0.5f, bot), boxU, 0.f, 0, thick);
            if (line) dl->AddLine(ImVec2(sw * 0.5f, sh), ImVec2(fs.x, bot), lineU, thick);
        }
    }
}
