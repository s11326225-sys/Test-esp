#include <jni.h>
#include <android/native_activity.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <vector>
#include <pthread.h>
#include <codecvt>
#include <chrono>
#include <unordered_map>
#include <vector>
#include <queue>
#include "ImGui/imgui_internal.h"
#include "ImGui/imgui.h"
#include "ImGui/backends/imgui_impl_android.h"
#include "ImGui/backends/imgui_impl_opengl3.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <sys/system_properties.h>
#include <string>
#include "ImGui/FONTS/DEFAULT.h"
#include <Includes/Utils.h>
#include <Includes/Dobby/dobby.h>
#include "esp_oxide.h"
#include "KittyMemory/MemoryPatch.h"
int screenWidth;
int screenHeight;
bool g_Initialized = false;
ImGuiWindow* g_window = NULL;
ImGuiWindow* g_window2 = NULL;
bool openMenu = false;
#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>
#include "Unity/Vector3.h"
#include "Unity/Rect.h"
const char *libName = "libil2cpp.so";
#include "And64InlineHook/And64InlineHook.hpp"
#include "monostring.h"
#include <dlfcn.h>
#include <android/log.h>
#include <cmath>
#include <iostream>
#include "Includes/msg.h"
#include <dlfcn.h>
#include <string>
#include "ByNameModding/Tools.h"
#include "ByNameModding/Il2Cpp.h"
#include "ByNameModding/fake_dlfcn.h"
#include <cmath>
#include "Chams.h"
#include "RGB.h"
#include "variables.h"
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2  
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2
ImVec4 boxColor = ImVec4(0.0f, 1.0f, 0.0f, 1.0f); // Green color for box
ImVec4 lineColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); // Red color for line
#define LOG_TAG "NinjarMods"
#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

//тоже важная хрень
extern "C" {
    
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_init(JNIEnv* env, jclass cls);
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_resize(JNIEnv* env, jobject obj, jint width, jint height);
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_step(JNIEnv* env, jobject obj);
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_imgui_Shutdown(JNIEnv* env, jobject obj);
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_MotionEventClick(JNIEnv* env, jobject obj,jboolean down,jfloat PosX,jfloat PosY);
    JNIEXPORT jstring JNICALL Java_com_mycompany_application_GLES3JNIView_getWindowRect(JNIEnv *env, jobject thiz);
    JNIEXPORT jstring JNICALL Java_com_mycompany_application_GLES3JNIView_getWindowRect2(JNIEnv *env, jobject thiz);     
    JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_real(JNIEnv* env, jobject obj, jint width, jint height);
    JNIEXPORT jboolean JNICALL Java_com_mycompany_application_MainActivity_menuClicable(JNIEnv *env, jobject thiz);
};
//конец

struct My_Patches {
    
    MemoryPatch h;
    
} hexPatches;
bool show_window;
int type = 1;
bool EspEnabled = false;
bool EspBox = false;
bool EspLine = false;
bool EspDistance = false;
bool needReinit = false;
bool initButtonPressed = false;
bool magbullet = false;
bool drawEnabled = false;
float drawSize = 80.0f;
ImVec4 drawColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);

float Thickness = 2.0f;
ImVec4 buttonHoverColor = ImVec4(0.2f, 0.8f, 0.2f, 1.0f);
void ReinitializePlayers();



void *(*get_transform)(void* transform);
Vector3 (*get_position)(void* pos);
Vector3 (*WorldToScreenPointt)(void* inst, Vector3 h);
void *(*Camera)();
bool (*get_isMine)();

Vector3 getPos(void *player) {
	return get_position(get_transform(player));
}
#define Hook(offset, ptr, orig) DobbyHook((void*)getAbsoluteAddress("libil2cpp.so", offset), (void*)ptr, (void**)&orig)

void* myPlayer = nullptr;
vector<void*> players;
bool playerFind(void *pl) {
    if (pl != NULL) {
        for (int i = 0; i < players.size(); ++i) {
            if (pl == players[i]) return true;
        }
    }
    return false;
}

void removePlayer(void *player) {
    for (int i = 0; i < players.size(); ++i) {
        if (players[i] == player) {
            players.erase(players.begin() + i);
            return;
        }
    }
}

void clearPlayers() {
    vector<void*> pls;
    for (int i = 0; i < players.size(); ++i) {
        if (players[i] != NULL) {
            pls.push_back(players[i]);
        }
    }
    players = pls;
}

void (*_OnDestroy) (void *plrr);
void OnDestroy (void *plrr) {
	players.clear();
	return _OnDestroy(plrr);
}

void (*_PlayerManager) (void *player);
void PlayerManager (void *player) {
	if (player) {
		bool isMine = get_isMine();
		if (isMine) {
			myPlayer = player;
		} else {
			if (!playerFind(player)) players.push_back(player);
		}
	}
	_PlayerManager(player);
}





void mystyle() {/*
ImGuiStyle& style = ImGui::GetStyle();
style.WindowRounding    = 0.0f;
style.ChildRounding     = 0.0f;
style.FrameRounding     = 0.0f;
style.PopupRounding     = 0.0f;
style.ScrollbarRounding = 0.0f;
style.GrabRounding      = 0.0f;
style.TabRounding       = 0.0f;*/
}

void SetCustomImGuiStyle()
{
    
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    // --- Скругления ---
    style.WindowRounding = 6.0f;       // Скругление окна
    style.FrameRounding = 4.0f;        // Скругление чекбоксов и полей
   // style.HeaderRounding = 4.0f;       // Скругление заголовков (CollapsingHeader)
    style.ScrollbarRounding = 12.0f;   // Скругление полосы прокрутки

    // --- Отступы ---
    style.WindowPadding = ImVec2(10, 10);
    style.FramePadding = ImVec2(6, 4);
    style.ItemSpacing = ImVec2(8, 8);

    // --- Цветовая схема ---
    
    // Фон окна (темно-серый с синеватым оттенком)
    colors[ImGuiCol_WindowBg] = ImVec4(0.12f, 0.14f, 0.18f, 0.95f); 
    
    // Заголовок окна (голубой/синий как на фото)
    colors[ImGuiCol_TitleBg] = ImVec4(0.40f, 0.55f, 0.72f, 1.00f);
    colors[ImGuiCol_TitleBgActive] = ImVec4(0.40f, 0.55f, 0.72f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.40f, 0.55f, 0.72f, 0.75f);

    // Заголовки разделов (CollapsingHeader)
    colors[ImGuiCol_Header] = ImVec4(0.35f, 0.50f, 0.65f, 1.00f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(0.40f, 0.55f, 0.72f, 1.00f);
    colors[ImGuiCol_HeaderActive] = ImVec4(0.30f, 0.45f, 0.60f, 1.00f);

    // Чекбоксы и слайдеры
    colors[ImGuiCol_FrameBg] = ImVec4(0.30f, 0.40f, 0.55f, 1.00f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.35f, 0.45f, 0.60f, 1.00f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.40f, 0.55f, 0.72f, 1.00f);
    
    // Галочка в чекбоксе
    colors[ImGuiCol_CheckMark] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);

    // Кнопки
    colors[ImGuiCol_Button] = ImVec4(0.40f, 0.55f, 0.72f, 1.00f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.45f, 0.60f, 0.75f, 1.00f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.35f, 0.50f, 0.65f, 1.00f);

    // Текст
    colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    
    // Скроллбар
    colors[ImGuiCol_ScrollbarBg] = ImVec4(0.15f, 0.15f, 0.15f, 0.00f);
    colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.50f, 0.50f, 0.50f, 0.80f);
}

//watermark color
void SetCustomWaterMarkStyle() {
	ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 10.0f);        // Сильное скругление углов
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 7));  // Внутренние отступы
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);      // Без обводки
     
    // Цвет фона: темно-серый с прозрачностью (RGBA)
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.12f, 0.12f, 0.12f, 0.75f)); 
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 2.0f);    // Скругление самого окна
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 2.0f);     // Скругление кнопок и полей
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 2.0f);     // Скругление дочерних окон
    
}

JNIEXPORT void JNICALL
Java_com_mycompany_application_GLES3JNIView_init(JNIEnv* env, jclass cls) {

    //SetUpImGuiContext
    if(!g_Initialized) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    
    int screenWidth = io.DisplaySize.x;
    int screenHeight = io.DisplaySize.y;
  
    ImGui_ImplOpenGL3_Init("#version 100");
    ImGui::GetStyle().ScaleAllSizes(2.5f);
    
    mystyle();
    ImGui::StyleColorsClassic();
    
    io.Fonts->AddFontFromFileTTF("/system/fonts/SourceSansPro-Bold.ttf", 25);

    g_Initialized = true;
    }
    return;
}

JNIEXPORT void JNICALL
Java_com_mycompany_application_GLES3JNIView_resize(JNIEnv* env, jobject obj, jint width, jint height) {
    if (g_Initialized) {
    screenWidth = (int) width;
    screenHeight = (int) height;
    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = NULL;
    ImGui::GetIO().DisplaySize = ImVec2((float)width, (float)height);
    }
    return;
}

/*void closebtn() {

// --- Кнопка закрытия в правом верхнем углу ---
ImGuiStyle& style = ImGui::GetStyle();
ImVec2 windowPos = ImGui::GetWindowPos();      // позиция окна в экранных координатах
ImVec2 windowSize = ImGui::GetWindowSize();    // размер окна

float closeSize = 20.0f;    // размер кнопки (ширина/высота)
float pad = 8.0f;           // отступ от правого/верхнего края
float titleBarHeight = ImGui::GetFontSize() + style.FramePadding.y * 2.0f; // примерная высота заголовка

// Вычисляем позицию кнопки (экранные координаты)
ImVec2 closePos = ImVec2(windowPos.x + windowSize.x - closeSize - pad,
                         windowPos.y + (titleBarHeight - closeSize) * 0.5f + pad * 0.0f);

// Поместим курсор на экранную позицию и отрисуем кнопку
ImGui::SetCursorScreenPos(closePos);
ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0,0,0,0));                 // фон (можешь подправить)
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.8f,0.2f,0.2f,0.9f));
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.9f,0.3f,0.3f,1.0f));

// "X##close" — видимое "X", а "##close" делает id уникальным без отображения лишнего
if (ImGui::Button("X##close", ImVec2(closeSize, closeSize))) {
    openMenu = false; // закрываем меню
}

ImGui::PopStyleColor(3);
ImGui::PopStyleVar();
// --- конец кнопки закрытия ---

}
*/

void DrawOpen() {
    SetCustomWaterMarkStyle();

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 2.0f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));

    // Позиционируем окно в правом верхнем углу с отступом 10px (pivot (1,0) — справа/сверху)
    ImGuiIO& io = ImGui::GetIO();
    ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x - 10.0f, 10.0f), ImGuiCond_Always, ImVec2(1.0f, 0.0f));

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove;
    if (!ImGui::Begin("soso", NULL, flags)) {
        ImGui::End();
        ImGui::PopStyleColor(); // WindowBg
        ImGui::PopStyleVar();   // WindowRounding
        return;
    }

    g_window2 = ImGui::GetCurrentWindow();

    float buttonWidth = 470.0f;
    float buttonHeight = 70.0f;
    ImVec2 buttonSize = ImVec2(buttonWidth, buttonHeight);

    // Установим масштаб шрифта для окна (влияет на весь текст в окне)
    float fontScale = 2.4f; // <- подкорректируй по вкусу
    ImGui::SetWindowFontScale(fontScale);

    ImVec4 buttonColor = ImVec4(0.352941f, 0.352941f, 0.356863f, 0.65f);
    ImVec4 buttonHoveredColor = ImVec4(0.392f, 0.392f, 0.4f, 0.65f);
    ImVec4 buttonActiveColor = ImVec4(0.32f, 0.32f, 0.34f, 0.65f);

    ImGui::PushStyleColor(ImGuiCol_Button, buttonColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, buttonHoveredColor);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, buttonActiveColor);

    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);

    if (ImGui::Button("Dear mods | user:id", buttonSize)) {
        openMenu = !openMenu;
    }

    ImGui::PopStyleVar();        // FrameRounding
    ImGui::PopStyleColor(3);     // Button, ButtonHovered, ButtonActive

    // Вернём масштаб шрифта к 1.0 (по умолчанию)
    ImGui::SetWindowFontScale(1.0f);

    ImGui::End();

    ImGui::PopStyleColor(); // WindowBg
    ImGui::PopStyleVar();   // WindowRounding
}

void BeginDraw() {
    SetCustomImGuiStyle();

    if (!openMenu)
        return;

    // Установить размер окна и (опционально) позицию в центре при первом показе
    ImGui::SetNextWindowSize(ImVec2(780, 585), ImGuiCond_Always);
    // Если хотите центрировать один раз:
    ImGui::SetNextWindowPos(ImVec2((screenWidth - 780) * 0.5f, (screenHeight - 585) * 0.5f), ImGuiCond_Once);

    // Выравнивание заголовка (не забываем потом PopStyleVar)
    ImGui::PushStyleVar(ImGuiStyleVar_WindowTitleAlign, ImVec2(0.5f, 0.5f));

    // Флаги: запрет сворачивания и изменения размера
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize;

    if (ImGui::Begin("@DearstudioV2", nullptr, flags)) {
        g_window = ImGui::GetCurrentWindow();
        //closebtn();
    

        if (ImGui::CollapsingHeader("Aim")) {
            ImGui::Checkbox("Magic bullets", &magbullet);
            ImGui::Checkbox(("Draw fov"), &drawEnabled);
                if (drawEnabled) {
                    ImGui::SliderFloat(("fov size"), &drawSize, 1.0f, 500.0f);
                    ImGui::ColorEdit4(("fov Color"), (float*)&drawColor);
                }
        }

        if (ImGui::CollapsingHeader("Esp")) {
            ImGui::Checkbox("ESP", &EspEnabled);
            if (EspEnabled) {
                ImGui::Checkbox("ESP Box", &EspBox);
                ImGui::Checkbox("ESP Line", &EspLine);
                ImGui::SliderFloat("Line Thickness", &Thickness, 1.0f, 5.0f);
                ImGui::ColorEdit4("Color Box", (float*)&boxColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
                ImGui::ColorEdit4("Color Line", (float*)&lineColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
            }
            ImGui::Separator();
        }

        if (ImGui::CollapsingHeader("Chams")) {
            if (chamsint > 1) ImGui::Separator();
				ImGui::PushItemWidth(500);
				ImGui::Combo(("Current Chams"), &chamsint, Chams, IM_ARRAYSIZE(Chams));
				if (chamsint > 1) {
                    ImGui::PushItemWidth(45);
                    ImGui::ColorEdit3(("##Visible Color"), (float *) &visibleColor);
                    ImGui::SameLine();
                    ImGui::Checkbox(("RGB"), &enableRainbow);
				}
                if (chamsint == 6 || chamsint == 7) {
                    ImGui::ColorEdit3(("##In Wall Color"), (float *) &inWallColor);
                    ImGui::SameLine();
                    ImGui::Checkbox(("RGB "), &enableRainbowWall);
                }
                ImGui::PushItemWidth(0);
				if (chamsint > 1) ImGui::Separator();
				
        }

        if (ImGui::CollapsingHeader("misc")) {
            // ...
        }
    }

    ImGui::End();
    ImGui::PopStyleVar(); // WindowTitleAlign
}





		//visual functions
		
		
		
		
		
		
		



void *hack_thread(void *) {
ProcMap il2cppMap;
    do {
     sleep(1);
    } while (!isLibraryLoaded(libName));
	
	LOGD("Library loaded, hooking functions...");
    esp::Init();
    
  
// removed: offset belongs to another build
// removed: offset belongs to another build

get_isMine = (bool(*)()) getAbsoluteAddress("libil2cpp.so", 0x1526354);
get_transform = (void *(*)(void*)) getAbsoluteAddress("libil2cpp.so", 0x2DEF510);
get_position = (Vector3 (*)(void*)) getAbsoluteAddress("libil2cpp.so", 0x196CB50);
Camera = (void *(*)()) getAbsoluteAddress("libil2cpp.so", 0x14FCBBC);
WorldToScreenPointt = (Vector3 (*)(void*, Vector3)) getAbsoluteAddress("libil2cpp.so", 0x15E53F0);
   
                                            
    return NULL;
}
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2
//Tg Chanel: https://t.me/dearstudioV2








JNIEXPORT void JNICALL
Java_com_mycompany_application_GLES3JNIView_step(JNIEnv* env, jobject obj) {
    if (g_Initialized) {
    ImGuiIO& io = ImGui::GetIO();
    
    //Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    
    DrawOpen();
    BeginDraw();
    if (EspEnabled) esp::Draw(EspBox, EspLine, boxColor, lineColor, Thickness);
if (false) {
    for (int i = 0; i < players.size(); ++i) {
        void* player = players[i];
        void* camera = Camera();

        if (!player || player == myPlayer) {
            continue;
        }
        
        Vector3 PlayerPos = getPos(player);
        Vector3 Head = Vector3(PlayerPos.x, PlayerPos.y + 1.6f, PlayerPos.z);
        Vector3 Bottom = Vector3(PlayerPos.x, PlayerPos.y, PlayerPos.z);
        Vector3 HeadPos = WorldToScreenPointt(camera, Head);
        Vector3 BottomPos = WorldToScreenPointt(camera, Bottom);
        
        if (HeadPos.z < 1.f || BottomPos.z < 1.f) continue;
        float boxHeight = abs(HeadPos.y - BottomPos.y);
        float boxWidth = boxHeight * 0.65f;
        Rect PlayerRect(HeadPos.x - (boxWidth / 2), (screenHeight - HeadPos.y), boxWidth, boxHeight);
        
        if (EspBox) {    
            ImU32 borderColor = ImGui::GetColorU32(boxColor);
            float thickness = 0.8f;
            ImGui::GetBackgroundDrawList()->AddRect(ImVec2(PlayerRect.x, PlayerRect.y), ImVec2(PlayerRect.x + PlayerRect.width, PlayerRect.y + PlayerRect.height), borderColor, 0.0f, 14, thickness);
        }
        
        if (EspLine) {
            if (HeadPos.z >= 1.0f) {
                ImU32 lineColorU32 = ImGui::GetColorU32(lineColor);
                ImGui::GetBackgroundDrawList()->AddLine(ImVec2(screenWidth / 2, 0), ImVec2(HeadPos.x, screenHeight - HeadPos.y), lineColorU32, Thickness);
            }
        }
    }
}
    // Рисование ESP после завершения интерфейса 
    
    if (drawEnabled) {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        ImVec2 screenCenter = ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);
        drawList->AddCircle(screenCenter, drawSize, ImColor(drawColor), 64, 2.0f);
    }
    
    if (enableRainbow) {
        visibleColor.x = redd/255;
        visibleColor.y = greenn/255;
        visibleColor.z = bluee/255;
    }
    if (enableRainbowWall) {
        inWallColor.x = redd/255;
        inWallColor.y = greenn/255;
        inWallColor.z = bluee/255;
    }
    performRGBChange();
    
    RenderNotifications();


    ImGui::EndFrame();
    
    ImGui::Render();
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    }
}

JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_imgui_Shutdown(JNIEnv* env, jobject obj){
    if (!g_Initialized)
        return;
     // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    g_Initialized=false;
}

JNIEXPORT void JNICALL Java_com_mycompany_application_GLES3JNIView_MotionEventClick(JNIEnv* env, jobject obj,jboolean down,jfloat PosX,jfloat PosY){
    if (g_Initialized) {
        ImGuiIO &io = ImGui::GetIO();
        io.MouseDown[0] = down;
        io.MousePos = ImVec2(PosX, PosY);
        
        // Также добавьте обработку отпускания кнопки
        if (!down) {
            io.MouseDown[0] = false;
        }
    }
}

JNIEXPORT jstring JNICALL Java_com_mycompany_application_GLES3JNIView_getWindowRect(JNIEnv *env, jobject thiz) {
    //get drawing window
    // TODO: accomplish getWindowSizePos()
    if (g_Initialized) {
    char result[512]="0|0|0|0";
    if(g_window){
        sprintf(result,"%d|%d|%d|%d",(int)g_window->Pos.x,(int)g_window->Pos.y,(int)g_window->Size.x,(int)g_window->Size.y);
    }
    return env->NewStringUTF(result);
    }
}

JNIEXPORT jstring JNICALL 
Java_com_mycompany_application_GLES3JNIView_getWindowRect2(JNIEnv *env, jobject thiz) {
    char result[512]="0|0|0|0";
    if(g_window2) {
        sprintf(result,"%d|%d|%d|%d",(int)g_window2->Pos.x,(int)g_window2->Pos.y,(int)g_window2->Size.x,(int)g_window2->Size.y);
    }

    return env->NewStringUTF(result);
}


JNIEXPORT jboolean JNICALL 
Java_com_mycompany_application_MainActivity_menuClicable(JNIEnv *env, jobject thiz) {
    return openMenu;
}



JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

   pthread_t gameThread = NULL;
    if (gameThread = pthread_self()) {
        pthread_create(&gameThread, NULL, hack_thread, NULL);
    }
    
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
//Tg Chanel: https://t.me/dearstudioV2