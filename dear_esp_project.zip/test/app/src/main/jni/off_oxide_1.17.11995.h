// oxide survival island (com.catsbit.oxidesurvuvalisland)
// build: arm64-v8a 1.17.11995  (from dump.cs header, check it matches the installed game!)
// all values are RVA relative to libil2cpp.so, taken from this dump.
// instance methods take (this, args..., MethodInfo*); the MethodInfo* arg is ignored when called via cast, same as main.cpp
#pragma once

namespace off {
    // UnityEngine.CoreModule
    constexpr unsigned long Camera_get_main            = 0xD6A78D0;   // public static Camera get_main()
    constexpr unsigned long Camera_WorldToScreenPoint  = 0xD6A6E24;   // public Vector3 WorldToScreenPoint(Vector3 position)
    constexpr unsigned long Camera_get_pixelWidth      = 0xD6A5558;   // public int get_pixelWidth()
    constexpr unsigned long Camera_get_pixelHeight     = 0xD6A560C;   // public int get_pixelHeight()
    constexpr unsigned long Component_get_transform    = 0xD72325C;   // public Transform get_transform()
    constexpr unsigned long Transform_get_position     = 0xD73C9FC;   // public Vector3 get_position()
    constexpr unsigned long Object_FindObjectsOfType_Type = 0xD73041C; // public static Object[] FindObjectsOfType(Type type)

    // Mirror (networking, all player/npc/object identity lives here)
    constexpr unsigned long NetworkIdentity_get_netId         = 0xCB38408; // public uint get_netId()
    constexpr unsigned long NetworkIdentity_get_isLocalPlayer = 0xCB383E8; // public bool get_isLocalPlayer()
    constexpr unsigned long NetworkBehaviour_get_isLocalPlayer = 0xCB25A48; // public bool get_isLocalPlayer()
    constexpr unsigned long NetworkBehaviour_get_netIdentity  = 0xCB25C10; // public NetworkIdentity get_netIdentity()

    // runtime lookup, NOT offsets (resolve with ByNameModding Il2CppGetStaticFieldValue / Il2CppGetClassType)
    // NetworkClient.spawned   : static Dictionary<uint, NetworkIdentity>  (static field 0x30 in the class static block)
    // NetworkClient.localPlayer: static NetworkIdentity                    (static field 0x48)
    // PlayerWeapon            : Assembly-CSharp, NetworkBehaviour, used as the player marker component
}
